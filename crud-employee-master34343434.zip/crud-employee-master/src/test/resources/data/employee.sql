delete from bdeleon.employee;
INSERT INTO bdeleon.employee VALUES
  ('aa3','naruto3','naruto@2gmail.com');