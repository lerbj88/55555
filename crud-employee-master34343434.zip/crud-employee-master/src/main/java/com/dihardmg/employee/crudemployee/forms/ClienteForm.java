package com.dihardmg.employee.crudemployee.forms;

public class ClienteForm {

    private String id;
    private String cliente;
    private String tienda;
    private String email;
    private String telefono;


    public ClienteForm() {
    }

    public ClienteForm(String id, String cliente, String tienda, String email, String telefono) {
        this.id = id;
        this.cliente = cliente;
        this.tienda = tienda;
        this.email = email;
        this.telefono = telefono;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public String getTienda() {
        return tienda;
    }

    public void setTienda(String tienda) {
        this.tienda = tienda;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

}


