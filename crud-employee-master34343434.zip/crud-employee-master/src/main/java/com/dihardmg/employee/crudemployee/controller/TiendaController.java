package com.dihardmg.employee.crudemployee.controller;

import com.dihardmg.employee.crudemployee.dao.TiendaDao;
import com.dihardmg.employee.crudemployee.entity.Tienda;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;

import javax.validation.Valid;


@Controller
@RequestMapping("/tienda")
public class TiendaController {

    @Autowired
    private TiendaDao tiendaDao;

    @GetMapping("/list")
    public ModelMap listaTienda(@PageableDefault(size = 5)Pageable pageable, @RequestParam(name = "value", required = false) String value, Model model){
        if (value != null){
            model.addAttribute("key", value);
            return new ModelMap().addAttribute("listaTienda", tiendaDao.findByFinotiendaContainingIgnoreCase(value, pageable));
        }else {
            return new ModelMap().addAttribute("listaTienda", tiendaDao.findAll(pageable));
        }
    }

    @RequestMapping("/eliminar")
    public String Eliminar (@RequestParam("id") String id){
        tiendaDao.delete(id);
        return "redirect:list";
    }

    @GetMapping("/form")
    public ModelMap Editar(@RequestParam(value = "id",required = false)Tienda tienda){
        if(tienda == null){
            tienda = new Tienda();
        }
        return new ModelMap("tienda", tienda);
    }


    @PostMapping("/form")
    public String Guardar( @ModelAttribute @Valid Tienda tienda, BindingResult errors, SessionStatus status){
        if (errors.hasErrors()){
            return "tienda/form";
        }
        //tiendaDao.save(tienda);
        tiendaDao.save(tienda);
        status.setComplete();
        return "redirect:list";
    }

}
