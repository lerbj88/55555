package com.dihardmg.employee.crudemployee.dao.impl;

import com.dihardmg.employee.crudemployee.dao.ClienteDao;
import com.dihardmg.employee.crudemployee.forms.ClienteForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.util.List;
import java.util.stream.Collectors;

@Repository
public class ClienteDaoImpl implements ClienteDao {

    @Autowired
    private EntityManager entityManager;

    @Override
    public String crearCliente(String id, String cliente, String tienda, String email, String telefono) {
        //"login" this is the name of your procedure
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery("insertcliente");

        //Declare the parameters in the same order
        query.registerStoredProcedureParameter(1, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(2, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(3, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(4, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(5, String.class, ParameterMode.IN);
        //query.registerStoredProcedureParameter(3, Integer.class, ParameterMode.OUT);
        query.registerStoredProcedureParameter(6, String.class, ParameterMode.OUT);

        //Pass the parameter values
        query.setParameter(1, id);
        query.setParameter(2, cliente);
        query.setParameter(3, tienda);
        query.setParameter(4, email);
        query.setParameter(5, telefono);


        //Execute query
        query.execute();

        //Get output parameters
        //Integer outCode = (Integer) query.getOutputParameterValue(3);
        String outMessage = (String) query.getOutputParameterValue(6);
        //System.out.printf(outMessage);
        return outMessage;
    }

    public List<ClienteForm> obtenerClientes () {

        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("SYSTEM.SP_SELECTCLIENTES");


        storedProcedureQuery.registerStoredProcedureParameter(1, Class.class, ParameterMode.REF_CURSOR);

        storedProcedureQuery.execute();

        // Obtenemos el resultado del cursos en una lista
        List<Object[]> results = storedProcedureQuery.getResultList();

        // Recorremos la lista con map y devolvemos un List<BusinessObject>
        List<ClienteForm> collect = results.stream().map(result -> new ClienteForm(
                (String) result[0],
                (String) result[1],
                (String) result[2],
                (String) result[3],
                (String) result[4]
        )).collect(Collectors.toList());

        return collect;
    }


}
