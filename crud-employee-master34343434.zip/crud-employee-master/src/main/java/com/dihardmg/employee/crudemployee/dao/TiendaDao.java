package com.dihardmg.employee.crudemployee.dao;

import com.dihardmg.employee.crudemployee.entity.Tienda;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface TiendaDao extends PagingAndSortingRepository<Tienda, String>{
    public Page<Tienda> findByFinotiendaContainingIgnoreCase(String finotienda, Pageable pageable);
}
