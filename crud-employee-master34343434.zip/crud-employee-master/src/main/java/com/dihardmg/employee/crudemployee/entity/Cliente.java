package com.dihardmg.employee.crudemployee.entity;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


@Entity
@Data
public class Cliente {


    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @Column(nullable = false, unique = true)
    @NotEmpty
    private String client;

    @Column(nullable = false, unique = true)
    @NotEmpty
    private String tienda;

    @Column(nullable = false, unique = true)
    @NotEmpty
    private String email;

    @Column(nullable = false, unique = true)
    @NotEmpty
    private String telefono;

   // @Column(nullable = false, unique = true)
    //@DateTimeFormat
    //@NotEmpty
    //private String fdfechaalta;

}
