package com.dihardmg.employee.crudemployee.controller;

import com.dihardmg.employee.crudemployee.dao.ClientDao;
import com.dihardmg.employee.crudemployee.dao.ClienteDao;
import com.dihardmg.employee.crudemployee.entity.Cliente;
import com.dihardmg.employee.crudemployee.forms.ClienteForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;

@Controller
@RequestMapping("/cliente")
public class ClienteController {


    @Autowired
    private ClientDao clientDao;

    @Autowired
    private ClienteDao clienteDao;


    @GetMapping("/list")
    public String listaClientes(@RequestParam(name = "cliente") String cliente,@RequestParam(name = "id") String id, @PageableDefault(size = 5) Pageable pageable, ModelMap modelMap){
    Page<Cliente> listaClientes = clientDao.findAllByClientAndAndId(cliente, id, pageable);
    modelMap.addAttribute("listaClientes", listaClientes);
            return "cliente/list";

    }

    @GetMapping("/form")
    public String form(ModelMap model){
        ClienteForm clienteForm = new ClienteForm();
        model.addAttribute("cliente", clienteForm);
        model.addAttribute("outMessage", "");
        return "cliente/form";
    }




    @PostMapping("/form")
    public String agregar(@ModelAttribute(value = "cliente") ClienteForm clienteForm, BindingResult errors, SessionStatus status, ModelMap model) {
        if (errors.hasErrors()) {
            return "cliente/form";
        }


         status.setComplete();
         String outMessage = clienteDao.crearCliente(clienteForm.getId(), clienteForm.getCliente(), clienteForm.getTienda(),clienteForm.getEmail(), clienteForm.getTelefono());
        //return "redirect:form";

        model.addAttribute("cliente", clienteForm);
        model.addAttribute("outMessage", outMessage);
        return "cliente/form";
    }




}