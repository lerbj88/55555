package com.dihardmg.employee.crudemployee.dao;

import com.dihardmg.employee.crudemployee.forms.ClienteForm;

import java.util.List;

public interface ClienteDao {

    String crearCliente(String id, String cliente, String tienda, String email, String telefono);
    List<ClienteForm> obtenerClientes () ;

}
