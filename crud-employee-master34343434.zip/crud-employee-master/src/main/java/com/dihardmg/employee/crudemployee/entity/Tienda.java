package com.dihardmg.employee.crudemployee.entity;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.validation.constraints.NotNull;


@Entity
@Data
public class Tienda {
    @Id @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @Column(nullable = false)
    @NotNull
    @NotEmpty
    private String finotienda;

    @Column(nullable = false, unique = true)
    @NotEmpty
    private String fipais;

    @Column(nullable = false, unique = true)
    @NotEmpty
    private String ficanal;

    @Column(nullable = false, unique = true)
    @NotEmpty
    private String fcdescripcion;

    @Column(nullable = false, unique = true)
    @NotEmpty
    private String fccp;

   // @Column(nullable = false, unique = true)
    //@DateTimeFormat
    //@NotEmpty
    //private String fdfechaalta;

}
